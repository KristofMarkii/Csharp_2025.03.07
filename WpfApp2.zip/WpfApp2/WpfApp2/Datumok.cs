﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
namespace WpfApp2
{
    public class Datumok : INotifyPropertyChanged
    {
        public DateTime aktualis;
        public DateTime szuletes;
        public int kor;

        public DateTime Aktualis 
        {
            get { return aktualis; }
            set 
            { 
                aktualis = value;
                OnPropertyCanged("Kor");
            }
        }
        public DateTime Szuletesi
        {
            get { return szuletes; }
            set
            {
                szuletes = value;
                OnPropertyCanged("Kor");
            }
        }
        public int Kor
        {
            get
            {
                kor = aktualis.Year - szuletes.Year;
                if (aktualis.Month < szuletes.Month || aktualis.Month == szuletes.Month && aktualis.Day < szuletes.Day)
                {
                    kor--;
                }
                return kor;
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyCanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            }
        }
    }
}
